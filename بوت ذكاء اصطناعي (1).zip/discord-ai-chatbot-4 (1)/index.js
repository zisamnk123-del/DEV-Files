const { Client, GatewayIntentBits, MessageAttachment } = require("discord.js");
const { Hercai } = require("hercai");
const Tesseract = require("tesseract.js");
var colors = require('colors');
const fetch = require("node-fetch");
const { startServer } = require("./By3ky.js");
const {
  allowed_channel_ids,
  token,
  image2textChannels,
} = require("./config.json");
const config = require('./config.json');
const herc = new Hercai();
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once("ready", () => {
  console.log(`Bot by General Progs`.blue);
  console.log(`Link Server Support : https://discord.gg/G-P `.red);
  console.log(`bot is Online !
User Bot :${client.user.tag} ! `.yellow);
});

async function extractTextFromImage(url) {
  try {
    const image = await fetch(url).then((res) => res.buffer());
    const textFromImage = await Tesseract.recognize(image, "eng");
    return textFromImage.data.text;
  } catch (error) {
    return "Error ";
  }
}

client.on("messageCreate", async (message) => {
  if (
    message.author.bot ||
    (!allowed_channel_ids.includes(message.channel.id) &&
      !image2textChannels.includes(message.channel.id))
  )
    return;

    await message.channel.sendTyping();

  let fullContent = message.content;

  if (
    message.attachments.size > 0 &&
    image2textChannels.includes(message.channel.id)
  ) {
    const attachment = message.attachments.first();
    if (attachment.contentType && attachment.contentType.startsWith("image/")) {
      try {
        const extractedText = await extractTextFromImage(attachment.url);
        await message.reply(`Extracted Text: ${extractedText}`);
      } catch (error) {
        await message.reply("اصبح الضغط على البوت عالي الرجاء الصبر ");
      }
    }
    return;
  }

  if (
    message.attachments.size > 0 &&
    allowed_channel_ids.includes(message.channel.id)
  ) {
    const attachment = message.attachments.first();
    if (attachment.contentType && attachment.contentType.startsWith("image/")) {
      try {
        const textFromImage = await extractTextFromImage(attachment.url);
        fullContent += ` [Image Content: ${textFromImage}]`;
      } catch (error) {
        await message.reply("Sorry, I had trouble reading that image.");
        return;
      }
    }
  }

  try {
    const response = await herc.question({
      model: "v3-beta",
      content: fullContent,
    });
    await message.reply(response.reply);
  } catch (error) {
    await message.reply(
      "اصبح الضغط على البوت عالي الرجاء الصبر ",
    );
  }
});

startServer();

client.login(config.token);